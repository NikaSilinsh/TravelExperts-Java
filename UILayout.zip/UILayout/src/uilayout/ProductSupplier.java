/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uilayout;

/**
 *
 * @author SarahFerguson
 */
public class ProductSupplier {
    private String PackageId;
    private String ProductSupplierId;
    private String ProductId;
    private String SupplierId;
    private String ProdName;
    private String SupName;

    /**
     * @return the PackageId
     */
    public String getPackageId() {
        return PackageId;
    }

    /**
     * @param PackageId the PackageId to set
     */
    public void setPackageId(String PackageId) {
        this.PackageId = PackageId;
    }

    /**
     * @return the ProductSupplierId
     */
    public String getProductSupplierId() {
        return ProductSupplierId;
    }

    /**
     * @param ProductSupplierId the ProductSupplierId to set
     */
    public void setProductSupplierId(String ProductSupplierId) {
        this.ProductSupplierId = ProductSupplierId;
    }

    /**
     * @return the ProductId
     */
    public String getProductId() {
        return ProductId;
    }

    /**
     * @param ProductId the ProductId to set
     */
    public void setProductId(String ProductId) {
        this.ProductId = ProductId;
    }

    /**
     * @return the SupplierId
     */
    public String getSupplierId() {
        return SupplierId;
    }

    /**
     * @param SupplierId the SupplierId to set
     */
    public void setSupplierId(String SupplierId) {
        this.SupplierId = SupplierId;
    }

    /**
     * @return the ProdName
     */
    public String getProdName() {
        return ProdName;
    }

    /**
     * @param ProdName the ProdName to set
     */
    public void setProdName(String ProdName) {
        this.ProdName = ProdName;
    }

    /**
     * @return the SupName
     */
    public String getSupName() {
        return SupName;
    }

    /**
     * @param SupName the SupName to set
     */
    public void setSupName(String SupName) {
        this.SupName = SupName;
    }
    
}
