/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uilayout;

/**
 *
 * @author 464336
 */
public class Package {
    private String packageId;
    private String pkgName;
    private String PkgStartDate;
    private String pkgEndDate;
    private String pkgDesc;
    private String pkgBasePrice;
    private String pkgAgencyCommission;

    /**
     * @return the packageId
     */
    public String getPackageId() {
        return packageId;
    }

    /**
     * @param packageId the packageId to set
     */
    public void setPackageId(String packageId) {
        this.packageId = packageId;
    }

    /**
     * @return the pkgName
     */
    public String getPkgName() {
        return pkgName;
    }

    /**
     * @param pkgName the pkgName to set
     */
    public void setPkgName(String pkgName) {
        this.pkgName = pkgName;
    }

    /**
     * @return the PkgStartDate
     */
    public String getPkgStartDate() {
        return PkgStartDate;
    }

    /**
     * @param PkgStartDate the PkgStartDate to set
     */
    public void setPkgStartDate(String PkgStartDate) {
        this.PkgStartDate = PkgStartDate;
    }

    /**
     * @return the pkgEndDate
     */
    public String getPkgEndDate() {
        return pkgEndDate;
    }

    /**
     * @param pkgEndDate the pkgEndDate to set
     */
    public void setPkgEndDate(String pkgEndDate) {
        this.pkgEndDate = pkgEndDate;
    }

    /**
     * @return the pkgDesc
     */
    public String getPkgDesc() {
        return pkgDesc;
    }

    /**
     * @param pkgDesc the pkgDesc to set
     */
    public void setPkgDesc(String pkgDesc) {
        this.pkgDesc = pkgDesc;
    }

    /**
     * @return the pkgBasePrice
     */
    public String getPkgBasePrice() {
        return pkgBasePrice;
    }

    /**
     * @param pkgBasePrice the pkgBasePrice to set
     */
    public void setPkgBasePrice(String pkgBasePrice) {
        this.pkgBasePrice = pkgBasePrice;
    }

    /**
     * @return the pkgAgencyCommission
     */
    public String getPkgAgencyCommission() {
        return pkgAgencyCommission;
    }

    /**
     * @param pkgAgencyCommission the pkgAgencyCommission to set
     */
    public void setPkgAgencyCommission(String pkgAgencyCommission) {
        this.pkgAgencyCommission = pkgAgencyCommission;
    }
    
}
