/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uilayout;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.NumberFormat;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 *
 * @author 464336
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private Button btnExit;
    @FXML
    private ListView<String> pkgProduct;
    @FXML
    private Button btnAdd;
    @FXML
    private ListView<String> allProduct;
    @FXML
    private Button btnBack;
    @FXML
    private Button btnNext;
    @FXML
    private Button btnEdit;
    @FXML
    private TextField pkgName;
    @FXML
    private DatePicker startDate;
    @FXML
    private DatePicker endDate;
    @FXML
    private TextArea pkgDescription;
    @FXML
    private TextField basePrice;
    @FXML
    private TextField agtCommission;
    @FXML
    private ComboBox cboPkgId;
    @FXML
    private Button btnSave;
    
   // private Connection conn;
    //private Statement stmt;
    //private ResultSet rs;
    private ArrayList<Package> listPackages;
    private ArrayList<ProductSupplier> listPkgProducts;
    private ArrayList<ProductSupplier> listAllProducts;
    
    
    
    private void handleButtonAction(ActionEvent event) {
 
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        try {
            cboPkgId.getItems().clear();
            cboPkgId.setItems(PackageDB.getPkgIds());
            listPackages = PackageDB.loadPackages();                 
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }    

    @FXML
    private void exit(ActionEvent event) {
        System.exit(0);
    }


    @FXML
    private void selectPkgId(ActionEvent event) throws ClassNotFoundException {
        String selectedID = (String) cboPkgId.getValue();
        for (Package pkg : listPackages)
        {
            String temp = pkg.getPackageId();
            if (temp.equals(selectedID)) {
                pkgName.setText(pkg.getPkgName());
                pkgDescription.setText(pkg.getPkgDesc());
                
                // Loads the start and end dates
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S");
                formatter = formatter.withLocale(Locale.CANADA);
                LocalDate date = LocalDate.parse(pkg.getPkgStartDate(), formatter);
                startDate.setValue(date);
                date = LocalDate.parse(pkg.getPkgEndDate(), formatter);
                endDate.setValue(date);
                
                // Loads the base price and commission
                NumberFormat nf = NumberFormat.getCurrencyInstance();
                Double price = Double.parseDouble(pkg.getPkgBasePrice());
                Double commission = Double.parseDouble(pkg.getPkgAgencyCommission());
                basePrice.setText(nf.format(price)); 
                agtCommission.setText(nf.format(commission));
                
                // Load first list box based on which products associated with package
                listPkgProducts = ProductSupplierDB.loadPkgProducts(pkg.getPackageId());
                List<String> list = new ArrayList<String>(); // temp list for loading into the listview box
                for (ProductSupplier prodSup : listPkgProducts)
                {
                    list.add(prodSup.getProdName() + " " + prodSup.getSupName());
                }
                ObservableList<String> pkgProducts = FXCollections.observableList(list);
                pkgProduct.setItems(pkgProducts);
                
                // Adds all the products except for the ones associated with package (DOES NOT WORK CURRENTLY)
                listAllProducts = ProductSupplierDB.getAllProducts();
                List<String> allProductsList = new ArrayList<String>(); // temp list for loading into the listview box
                for (ProductSupplier prodSup : listAllProducts)
                {
                    if (!listPkgProducts.contains(prodSup))
                    {
                        allProductsList.add(prodSup.getProdName() + " " + prodSup.getSupName());
                    }
                }
                ObservableList<String> allProducts = FXCollections.observableList(allProductsList);
                allProduct.setItems(allProducts);               
            }
        }
    }

    @FXML
    private void addNewPackage(ActionEvent event) {
        btnSave.setDisable(false);
        btnEdit.setDisable(true);
        btnAdd.setDisable(true);
        clearFields();
    }
    
    @FXML
    private void savePackage(ActionEvent event) throws ParseException, ClassNotFoundException, SQLException {
        btnSave.setDisable(true);
        btnEdit.setDisable(false);
        btnAdd.setDisable(false);
        // Add validation
        Package pkg = new Package();
        pkg.setPkgName(pkgName.getText());
        pkg.setPkgStartDate(startDate.getValue().toString());
        pkg.setPkgEndDate(endDate.getValue().toString());
        pkg.setPkgDesc(pkgDescription.getText());
        NumberFormat format = NumberFormat.getCurrencyInstance();
        Number price = format.parse(basePrice.getText());
        Number commission = format.parse(agtCommission.getText());
        pkg.setPkgBasePrice(price.toString());
        pkg.setPkgAgencyCommission(commission.toString());
        //PackageDB.savePackage(pkg);
        System.out.println(pkg.getPkgName() + " " + pkg.getPkgStartDate() + " " + pkg.getPkgEndDate() + " " + pkg.getPkgDesc() + " " + pkg.getPkgBasePrice() +  " " + pkg.getPkgAgencyCommission());
    }

    private void clearFields() {
        pkgName.setText("");
        startDate.setValue(null);
        endDate.setValue(null);
        pkgDescription.setText("");
        basePrice.setText("");
        agtCommission.setText("");
        pkgProduct.setItems(null);
    }
    
}
